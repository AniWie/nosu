﻿namespace Notepad
{
    partial class FormMain
    {
        private System.ComponentModel.IContainer components = null;
        
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }
        
        #region Windows Form Designer generated code
		
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            menuStripMainMenu = new MenuStrip();
            menuFile = new ToolStripMenuItem();
            menuCreate = new ToolStripMenuItem();
            menuOpen = new ToolStripMenuItem();
            menuSave = new ToolStripMenuItem();
            menuSaveAs = new ToolStripMenuItem();
            menuSeparatorFile = new ToolStripSeparator();
            menuExit = new ToolStripMenuItem();
            menuEdit = new ToolStripMenuItem();
            menuCopy = new ToolStripMenuItem();
            menuCut = new ToolStripMenuItem();
            menuPaste = new ToolStripMenuItem();
            menuSeparatorEdit = new ToolStripSeparator();
            menuSelectAll = new ToolStripMenuItem();
            menuFormat = new ToolStripMenuItem();
            menuFont = new ToolStripMenuItem();
            menuColor = new ToolStripMenuItem();
            menuSettings = new ToolStripMenuItem();
            toolStripMain = new ToolStrip();
            buttonBold = new ToolStripButton();
            buttonColor = new ToolStripButton();
            toolStripSeparator1 = new ToolStripSeparator();
            panelEditor = new Panel();
            textBoxField = new TextBox();
            contextMenuStripTextBoxField = new ContextMenuStrip(components);
            contextCopy = new ToolStripMenuItem();
            contextCut = new ToolStripMenuItem();
            contextPaste = new ToolStripMenuItem();
            contextSeparator = new ToolStripSeparator();
            contextSelectAll = new ToolStripMenuItem();
            statusStripMain = new StatusStrip();
            statusFile = new ToolStripStatusLabel();
            statusSpring = new ToolStripStatusLabel();
            statusCount = new ToolStripStatusLabel();
            openFileDialog = new OpenFileDialog();
            saveFileDialog = new SaveFileDialog();
            fontDialog = new FontDialog();
            colorDialog = new ColorDialog();
            menuStripMainMenu.SuspendLayout();
            toolStripMain.SuspendLayout();
            panelEditor.SuspendLayout();
            contextMenuStripTextBoxField.SuspendLayout();
            statusStripMain.SuspendLayout();
            SuspendLayout();
			
            menuStripMainMenu.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point, 204);
            menuStripMainMenu.Items.AddRange(new ToolStripItem[] { menuFile, menuEdit, menuFormat, menuSettings });
            menuStripMainMenu.Location = new Point(0, 0);
            menuStripMainMenu.Name = "menuStripMainMenu";
            menuStripMainMenu.Size = new Size(900, 28);
            menuStripMainMenu.TabIndex = 0;
			
            menuStripMainMenu.Text = "menuStrip1";
            menuFile.DropDownItems.AddRange(new ToolStripItem[] { menuCreate, menuOpen, menuSave, menuSaveAs, menuSeparatorFile, menuExit });
            menuFile.Name = "menuFile";
            menuFile.Size = new Size(50, 24);
            menuFile.Text = "Файл";
    			        
            menuCreate.Name = "menuCreate";
            menuCreate.ShortcutKeys = Keys.Control | Keys.N;
            menuCreate.Size = new Size(210, 24);
            menuCreate.Text = "Создать";
            menuCreate.Click += menuCreate_Click;
			
            menuOpen.Name = "menuOpen";
            menuOpen.ShortcutKeys = Keys.Control | Keys.O;
            menuOpen.Size = new Size(210, 24);
            menuOpen.Text = "Открыть";
            menuOpen.Click += menuOpen_Click;
			
            menuSave.Name = "menuSave";
            menuSave.ShortcutKeys = Keys.Control | Keys.S;
            menuSave.Size = new Size(210, 24);
            menuSave.Text = "Сохранить";
            menuSave.Click += menuSave_Click;
			
            menuSaveAs.Name = "menuSaveAs";
            menuSaveAs.ShortcutKeys = Keys.Control | Keys.Shift | Keys.S;
            menuSaveAs.Size = new Size(210, 24);
            menuSaveAs.Text = "Сохранить как";
            menuSaveAs.Click += menuSaveAs_Click;
			
            menuSeparatorFile.Name = "menuSeparatorFile";
            menuSeparatorFile.Size = new Size(207, 6);
			
            menuExit.Name = "menuExit";
            menuExit.Size = new Size(210, 24);
            menuExit.Text = "Выход";
            menuExit.Click += menuExit_Click;
			
            menuEdit.DropDownItems.AddRange(new ToolStripItem[] { menuCopy, menuCut, menuPaste, menuSeparatorEdit, menuSelectAll });
            menuEdit.Name = "menuEdit";
            menuEdit.Size = new Size(59, 24);
            menuEdit.Text = "Правка";
			
            menuCopy.Name = "menuCopy";
            menuCopy.ShortcutKeys = Keys.Control | Keys.C;
            menuCopy.Size = new Size(210, 24);
            menuCopy.Text = "Копировать";
            menuCopy.Click += menuCopy_Click;
			
            menuCut.Name = "menuCut";
            menuCut.ShortcutKeys = Keys.Control | Keys.X;
            menuCut.Size = new Size(210, 24);
            menuCut.Text = "Вырезать";
            menuCut.Click += menuCut_Click;
			
            menuPaste.Name = "menuPaste";
            menuPaste.ShortcutKeys = Keys.Control | Keys.V;
            menuPaste.Size = new Size(210, 24);
            menuPaste.Text = "Вставить";
            menuPaste.Click += menuPaste_Click;
			
            menuSeparatorEdit.Name = "menuSeparatorEdit";
            menuSeparatorEdit.Size = new Size(207, 6);
			
            menuSelectAll.Name = "menuSelectAll";
            menuSelectAll.ShortcutKeys = Keys.Control | Keys.A;
            menuSelectAll.Size = new Size(210, 24);
            menuSelectAll.Text = "Выделить все";
            menuSelectAll.Click += menuSelectAll_Click;
			
            menuFormat.DropDownItems.AddRange(new ToolStripItem[] { menuFont, menuColor });
            menuFormat.Name = "menuFormat";
            menuFormat.Size = new Size(66, 24);
            menuFormat.Text = "Формат";
			
            menuFont.Name = "menuFont";
            menuFont.Size = new Size(110, 24);
            menuFont.Text = "Шрифт";
            menuFont.Click += menuFont_Click;
			
            menuColor.Name = "menuColor";
            menuColor.Size = new Size(110, 24);
            menuColor.Text = "Цвет";
            menuColor.Click += menuColor_Click;
			
            menuSettings.Name = "menuSettings";
            menuSettings.Size = new Size(90, 24);
            menuSettings.Text = "Настройки";
            menuSettings.Click += menuSettings_Click;
			
            toolStripMain.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point, 204);
            toolStripMain.GripStyle = ToolStripGripStyle.Hidden;
            toolStripMain.Items.AddRange(new ToolStripItem[] { buttonBold, buttonColor, toolStripSeparator1 });
            toolStripMain.Location = new Point(0, 28);
            toolStripMain.Name = "toolStripMain";
            toolStripMain.Padding = new Padding(8, 4, 8, 4);
            toolStripMain.Size = new Size(900, 34);
            toolStripMain.TabIndex = 1;
			
            buttonBold.AutoSize = false;
            buttonBold.DisplayStyle = ToolStripItemDisplayStyle.Text;
            buttonBold.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            buttonBold.Name = "buttonBold";
            buttonBold.Size = new Size(34, 26);
            buttonBold.Text = "Ж";
            buttonBold.ToolTipText = "Жирный шрифт";
            buttonBold.Click += buttonBold_Click;
			
            buttonColor.AutoSize = false;
            buttonColor.DisplayStyle = ToolStripItemDisplayStyle.Text;
            buttonColor.Name = "buttonColor";
            buttonColor.Size = new Size(64, 26);
            buttonColor.Text = "Цвет";
            buttonColor.ToolTipText = "Цвет текста";
            buttonColor.Click += buttonColor_Click;
			
            toolStripSeparator1.Name = "toolStripSeparator1";
            toolStripSeparator1.Size = new Size(6, 26);
			
            panelEditor.BackColor = Color.FromArgb(244, 244, 244);
            panelEditor.Controls.Add(textBoxField);
            panelEditor.Dock = DockStyle.Fill;
            panelEditor.Location = new Point(0, 62);
            panelEditor.Name = "panelEditor";
            panelEditor.Padding = new Padding(16, 12, 16, 12);
            panelEditor.Size = new Size(900, 536);
            panelEditor.TabIndex = 2;
			
            textBoxField.AcceptsTab = true;
            textBoxField.BackColor = Color.White;
            textBoxField.BorderStyle = BorderStyle.None;
            textBoxField.ContextMenuStrip = contextMenuStripTextBoxField;
            textBoxField.Dock = DockStyle.Fill;
            textBoxField.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 204);
            textBoxField.ForeColor = Color.FromArgb(31, 31, 31);
            textBoxField.Location = new Point(16, 12);
            textBoxField.Multiline = true;
            textBoxField.Name = "textBoxField";
            textBoxField.ScrollBars = ScrollBars.Vertical;
            textBoxField.Size = new Size(868, 512);
            textBoxField.TabIndex = 0;
            textBoxField.TextChanged += textBoxField_TextChanged;
			
            contextMenuStripTextBoxField.Items.AddRange(new ToolStripItem[] { contextCopy, contextCut, contextPaste, contextSeparator, contextSelectAll });
            contextMenuStripTextBoxField.Name = "contextMenuStripTextBoxField";
            contextMenuStripTextBoxField.Size = new Size(154, 98);
			
            contextCopy.Name = "contextCopy";
            contextCopy.Size = new Size(153, 22);
            contextCopy.Text = "Копировать";
            contextCopy.Click += menuCopy_Click;
			
            contextCut.Name = "contextCut";
            contextCut.Size = new Size(153, 22);
            contextCut.Text = "Вырезать";
            contextCut.Click += menuCut_Click;
			
            contextPaste.Name = "contextPaste";
            contextPaste.Size = new Size(153, 22);
            contextPaste.Text = "Вставить";
            contextPaste.Click += menuPaste_Click;
			
            contextSeparator.Name = "contextSeparator";
            contextSeparator.Size = new Size(150, 6);
			
            contextSelectAll.Name = "contextSelectAll";
            contextSelectAll.Size = new Size(153, 22);
            contextSelectAll.Text = "Выделить все";
            contextSelectAll.Click += menuSelectAll_Click;
			
            statusStripMain.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 204);
            statusStripMain.Items.AddRange(new ToolStripItem[] { statusFile, statusSpring, statusCount });
            statusStripMain.Location = new Point(0, 598);
            statusStripMain.Name = "statusStripMain";
            statusStripMain.Size = new Size(900, 22);
            statusStripMain.SizingGrip = false;
            statusStripMain.TabIndex = 3;
			
            statusFile.Name = "statusFile";
            statusFile.Size = new Size(83, 17);
            statusFile.Text = "Безымянный";
			
            statusSpring.Name = "statusSpring";
            statusSpring.Size = new Size(754, 17);
            statusSpring.Spring = true;
			
            statusCount.Name = "statusCount";
            statusCount.Size = new Size(48, 17);
            statusCount.Text = "Символов: 0";
			
            openFileDialog.FileName = "openFileDialog1";
            openFileDialog.Filter = "Текстовые документы|*.txt|Все файлы|*.*";
            openFileDialog.InitialDirectory = "C:\\";
			
            saveFileDialog.DefaultExt = "txt";
            saveFileDialog.FileName = "Безымянный";
            saveFileDialog.Filter = "Текстовые документы|*.txt|Все файлы|*.*";
            saveFileDialog.InitialDirectory = "C:\\";
			
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(244, 244, 244);
            ClientSize = new Size(900, 620);
            Controls.Add(panelEditor);
            Controls.Add(statusStripMain);
            Controls.Add(toolStripMain);
            Controls.Add(menuStripMainMenu);
            Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 204);
            MainMenuStrip = menuStripMainMenu;
            MinimumSize = new Size(640, 420);
            Name = "FormMain";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Блокнот";
            FormClosing += FormMain_FormClosing;
            Load += FormMain_Load;
            menuStripMainMenu.ResumeLayout(false);
            menuStripMainMenu.PerformLayout();
            toolStripMain.ResumeLayout(false);
            toolStripMain.PerformLayout();
            panelEditor.ResumeLayout(false);
            panelEditor.PerformLayout();
            contextMenuStripTextBoxField.ResumeLayout(false);
            statusStripMain.ResumeLayout(false);
            statusStripMain.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStripMainMenu;
        private ToolStripMenuItem menuFile;
        private ToolStripMenuItem menuCreate;
        private ToolStripMenuItem menuOpen;
        private ToolStripMenuItem menuSave;
        private ToolStripMenuItem menuSaveAs;
        private ToolStripSeparator menuSeparatorFile;
        private ToolStripMenuItem menuExit;
        private ToolStripMenuItem menuEdit;
        private ToolStripMenuItem menuCopy;
        private ToolStripMenuItem menuCut;
        private ToolStripMenuItem menuPaste;
        private ToolStripSeparator menuSeparatorEdit;
        private ToolStripMenuItem menuSelectAll;
        private ToolStripMenuItem menuFormat;
        private ToolStripMenuItem menuFont;
        private ToolStripMenuItem menuColor;
        private ToolStripMenuItem menuSettings;
        private ToolStrip toolStripMain;
        private ToolStripButton buttonBold;
        private ToolStripButton buttonColor;
        private ToolStripSeparator toolStripSeparator1;
        private Panel panelEditor;
        private TextBox textBoxField;
        private ContextMenuStrip contextMenuStripTextBoxField;
        private ToolStripMenuItem contextCopy;
        private ToolStripMenuItem contextCut;
        private ToolStripMenuItem contextPaste;
        private ToolStripSeparator contextSeparator;
        private ToolStripMenuItem contextSelectAll;
        private StatusStrip statusStripMain;
        private ToolStripStatusLabel statusFile;
        private ToolStripStatusLabel statusSpring;
        private ToolStripStatusLabel statusCount;
        private OpenFileDialog openFileDialog;
        private SaveFileDialog saveFileDialog;
        private FontDialog fontDialog;
        private ColorDialog colorDialog;
    }
}
