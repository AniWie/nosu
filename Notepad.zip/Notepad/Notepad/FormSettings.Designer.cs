﻿namespace Notepad
{
    partial class FormSettings
    {
		
        private System.ComponentModel.IContainer components = null;

		
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

		
        private void InitializeComponent()
        {
            labelFontSize = new Label();
            numericUpDownFontSize = new NumericUpDown();
            labelSign = new Label();
            textBoxSign = new TextBox();
            buttonSave = new Button();
            buttonCancel = new Button();
            ((System.ComponentModel.ISupportInitialize)numericUpDownFontSize).BeginInit();
            SuspendLayout();
		    
            labelFontSize.AutoSize = true;
            labelFontSize.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point, 204);
            labelFontSize.Location = new Point(28, 30);
            labelFontSize.Name = "labelFontSize";
            labelFontSize.Size = new Size(108, 19);
            labelFontSize.TabIndex = 0;
            labelFontSize.Text = "Размер шрифта";
		    
            numericUpDownFontSize.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point, 204);
            numericUpDownFontSize.Increment = new decimal(new int[] { 2, 0, 0, 0 });
            numericUpDownFontSize.Location = new Point(168, 27);
            numericUpDownFontSize.Maximum = new decimal(new int[] { 28, 0, 0, 0 });
            numericUpDownFontSize.Minimum = new decimal(new int[] { 8, 0, 0, 0 });
            numericUpDownFontSize.Name = "numericUpDownFontSize";
            numericUpDownFontSize.Size = new Size(70, 25);
            numericUpDownFontSize.TabIndex = 1;
            numericUpDownFontSize.Value = new decimal(new int[] { 14, 0, 0, 0 });
		    
            labelSign.AutoSize = true;
            labelSign.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point, 204);
            labelSign.Location = new Point(28, 72);
            labelSign.Name = "labelSign";
            labelSign.Size = new Size(60, 19);
            labelSign.TabIndex = 2;
            labelSign.Text = "Подпись";
  		    
            textBoxSign.BorderStyle = BorderStyle.FixedSingle;
            textBoxSign.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point, 204);
            textBoxSign.Location = new Point(28, 98);
            textBoxSign.Multiline = true;
            textBoxSign.Name = "textBoxSign";
            textBoxSign.ScrollBars = ScrollBars.Vertical;
            textBoxSign.Size = new Size(304, 70);
            textBoxSign.TabIndex = 3;
		    
            buttonSave.BackColor = Color.FromArgb(51, 85, 110);
            buttonSave.Cursor = Cursors.Hand;
            buttonSave.FlatAppearance.BorderSize = 0;
            buttonSave.FlatAppearance.MouseDownBackColor = Color.FromArgb(38, 66, 87);
            buttonSave.FlatAppearance.MouseOverBackColor = Color.FromArgb(60, 99, 127);
            buttonSave.FlatStyle = FlatStyle.Flat;
            buttonSave.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point, 204);
            buttonSave.ForeColor = Color.White;
            buttonSave.Location = new Point(118, 190);
            buttonSave.Name = "buttonSave";
            buttonSave.Size = new Size(104, 34);
            buttonSave.TabIndex = 4;
            buttonSave.Text = "Сохранить";
            buttonSave.UseVisualStyleBackColor = false;
            buttonSave.Click += buttonSave_Click;
		    
            buttonCancel.BackColor = Color.White;
            buttonCancel.Cursor = Cursors.Hand;
            buttonCancel.FlatAppearance.BorderColor = Color.FromArgb(210, 210, 210);
            buttonCancel.FlatAppearance.MouseDownBackColor = Color.FromArgb(232, 232, 232);
            buttonCancel.FlatAppearance.MouseOverBackColor = Color.FromArgb(242, 242, 242);
            buttonCancel.FlatStyle = FlatStyle.Flat;
            buttonCancel.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point, 204);
            buttonCancel.Location = new Point(228, 190);
            buttonCancel.Name = "buttonCancel";
            buttonCancel.Size = new Size(104, 34);
            buttonCancel.TabIndex = 5;
            buttonCancel.Text = "Отмена";
            buttonCancel.UseVisualStyleBackColor = false;
            buttonCancel.Click += buttonCancel_Click;
		    
            AcceptButton = buttonSave;
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(246, 243, 236);
            CancelButton = buttonCancel;
            ClientSize = new Size(360, 252);
            Controls.Add(buttonCancel);
            Controls.Add(buttonSave);
            Controls.Add(textBoxSign);
            Controls.Add(labelSign);
            Controls.Add(numericUpDownFontSize);
            Controls.Add(labelFontSize);
            Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 204);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "FormSettings";
            ShowInTaskbar = false;
            StartPosition = FormStartPosition.CenterParent;
            Text = "Настройки";
            ((System.ComponentModel.ISupportInitialize)numericUpDownFontSize).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label labelFontSize;
        private NumericUpDown numericUpDownFontSize;
        private Label labelSign;
        private TextBox textBoxSign;
        private Button buttonSave;
        private Button buttonCancel;
    }
}
