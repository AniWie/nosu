﻿namespace Notepad
{
    public partial class FormSettings : Form
    {
        public FormSettings()
        {
            InitializeComponent();
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            StreamWriter sw = new StreamWriter("settings.txt");
            sw.WriteLine(numericUpDownFontSize.Value);
            sw.WriteLine(textBoxSign.Text);
            sw.Close();

            Close();
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
