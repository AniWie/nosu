﻿namespace Notepad
{
    public partial class FormMain : Form
    {
        string current_filename = "";
        bool wasChanged = false;
        string sign = "";

        public FormMain()
        {
            InitializeComponent();
        }

        private void FormMain_Load(object sender, EventArgs e)
        {
            StreamReader sr = new StreamReader("settings.txt");
            int fontSize = int.Parse(sr.ReadLine());
            textBoxField.Font = new Font(textBoxField.Font.FontFamily, fontSize);

            sign = "";
            while (!sr.EndOfStream)
            {
                sign += "\r\n" + sr.ReadLine();
            }
            sr.Close();

            fontDialog.Font = textBoxField.Font;
            colorDialog.Color = textBoxField.ForeColor;

            UpdateStatus();
        }

        void UpdateStatus()
        {
            string name = current_filename == "" ? "Безымянный" : Path.GetFileName(current_filename);

            statusFile.Text = name;
            statusCount.Text = "Символов: " + textBoxField.Text.Length;
            Text = "Блокнот — " + name + (wasChanged ? " *" : "");
        }

        bool SaveChanges()
        {
            DialogResult result = MessageBox.Show("Сохранить изменения?", "Блокнот",
                MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);

            if (result == DialogResult.Cancel)
                return false;

            if (result == DialogResult.Yes)
                return Save();

            return true;
        }

        bool Save()
        {
            if (current_filename == "")
                return SaveAs();

            SaveToFile(current_filename);
            return true;
        }

        bool SaveAs()
        {
            if (saveFileDialog.ShowDialog() != DialogResult.OK)
                return false;

            current_filename = saveFileDialog.FileName;
            SaveToFile(current_filename);
            return true;
        }

        void SaveToFile(string filename)
        {
            StreamWriter sw = new StreamWriter(filename);
            sw.WriteLine(textBoxField.Text);
            if (sign != "")
                sw.WriteLine(sign);
            sw.Close();

            wasChanged = false;
            UpdateStatus();
        }

        private void menuCreate_Click(object sender, EventArgs e)
        {
            if (wasChanged && !SaveChanges())
                return;

            textBoxField.Text = "";
            current_filename = "";
            wasChanged = false;
            UpdateStatus();
        }

        private void menuOpen_Click(object sender, EventArgs e)
        {
            if (wasChanged && !SaveChanges())
                return;

            if (openFileDialog.ShowDialog() != DialogResult.OK)
                return;

            StreamReader sr = new StreamReader(openFileDialog.FileName);
            textBoxField.Text = sr.ReadToEnd();
            sr.Close();

            current_filename = openFileDialog.FileName;
            wasChanged = false;
            UpdateStatus();
        }

        private void menuSave_Click(object sender, EventArgs e)
        {
            Save();
        }

        private void menuSaveAs_Click(object sender, EventArgs e)
        {
            SaveAs();
        }

        private void menuExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void menuCopy_Click(object sender, EventArgs e)
        {
            textBoxField.Copy();
        }

        private void menuCut_Click(object sender, EventArgs e)
        {
            textBoxField.Cut();
        }

        private void menuPaste_Click(object sender, EventArgs e)
        {
            textBoxField.Paste();
        }

        private void menuSelectAll_Click(object sender, EventArgs e)
        {
            textBoxField.SelectAll();
        }

        private void menuFont_Click(object sender, EventArgs e)
        {
            if (fontDialog.ShowDialog() == DialogResult.OK)
            {
                textBoxField.Font = fontDialog.Font;
                buttonBold.Checked = fontDialog.Font.Bold;
            }
        }

        private void menuColor_Click(object sender, EventArgs e)
        {
            if (colorDialog.ShowDialog() == DialogResult.OK)
            {
                textBoxField.ForeColor = colorDialog.Color;
            }
        }

        private void menuSettings_Click(object sender, EventArgs e)
        {
            FormSettings frm = new FormSettings();
            frm.ShowDialog();
        }

        private void buttonBold_Click(object sender, EventArgs e)
        {
            FontStyle style = textBoxField.Font.Style;

            if ((style & FontStyle.Bold) == FontStyle.Bold)
                style = style & ~FontStyle.Bold;
            else
                style = style | FontStyle.Bold;

            textBoxField.Font = new Font(textBoxField.Font.FontFamily, textBoxField.Font.Size, style);
            buttonBold.Checked = (style & FontStyle.Bold) == FontStyle.Bold;
        }

        private void buttonColor_Click(object sender, EventArgs e)
        {
            menuColor_Click(sender, e);
        }

        private void textBoxField_TextChanged(object sender, EventArgs e)
        {
            wasChanged = true;
            UpdateStatus();
        }

        private void FormMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (wasChanged && !SaveChanges())
            {
                e.Cancel = true;
            }
        }
    }
}
