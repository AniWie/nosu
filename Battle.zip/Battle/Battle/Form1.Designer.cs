﻿namespace Battle
{
    partial class FormMain
    {
        
        private System.ComponentModel.IContainer components = null;

        
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

		
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormMain));
            labelHint = new Label();
            labelTitle = new Label();
            pictureBoxBoom = new PictureBox();
            pictureBoxCanonBall = new PictureBox();
            pictureBoxCanon = new PictureBox();
            pictureBoxShip = new PictureBox();
            timerShip = new System.Windows.Forms.Timer(components);
            timerCanonBall = new System.Windows.Forms.Timer(components);
            ((System.ComponentModel.ISupportInitialize)pictureBoxBoom).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxCanonBall).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxCanon).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxShip).BeginInit();
            SuspendLayout();
		    
            labelHint.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            labelHint.AutoSize = true;
            labelHint.BackColor = Color.Transparent;
            labelHint.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point, 204);
            labelHint.ForeColor = Color.White;
            labelHint.Location = new Point(30, 600);
            labelHint.Name = "labelHint";
            labelHint.Size = new Size(249, 20);
            labelHint.TabIndex = 0;
            labelHint.Text = "Пробел - выстрел · Esc - выход";
		    
            labelTitle.AutoSize = true;
            labelTitle.BackColor = Color.Transparent;
            labelTitle.Font = new Font("Segoe UI", 20F, FontStyle.Bold, GraphicsUnit.Point, 204);
            labelTitle.ForeColor = Color.FromArgb(20, 59, 76);
            labelTitle.Location = new Point(30, 20);
            labelTitle.Name = "labelTitle";
            labelTitle.Size = new Size(182, 37);
            labelTitle.TabIndex = 1;
            labelTitle.Text = "Морской бой";
		    
            pictureBoxBoom.Image = (Image)resources.GetObject("pictureBoxBoom.Image");
            pictureBoxBoom.Location = new Point(550, 258);
            pictureBoxBoom.Name = "pictureBoxBoom";
            pictureBoxBoom.Size = new Size(159, 157);
            pictureBoxBoom.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBoxBoom.TabIndex = 2;
            pictureBoxBoom.TabStop = false;
            pictureBoxBoom.Visible = false;
		    
            pictureBoxCanonBall.Image = (Image)resources.GetObject("pictureBoxCanonBall.Image");
            pictureBoxCanonBall.Location = new Point(425, 522);
            pictureBoxCanonBall.Name = "pictureBoxCanonBall";
            pictureBoxCanonBall.Size = new Size(18, 21);
            pictureBoxCanonBall.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBoxCanonBall.TabIndex = 3;
            pictureBoxCanonBall.TabStop = false;
            pictureBoxCanonBall.Visible = false;
		    
            pictureBoxCanon.Image = (Image)resources.GetObject("pictureBoxCanon.Image");
            pictureBoxCanon.Location = new Point(388, 542);
            pictureBoxCanon.Name = "pictureBoxCanon";
            pictureBoxCanon.Size = new Size(63, 113);
            pictureBoxCanon.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBoxCanon.TabIndex = 4;
            pictureBoxCanon.TabStop = false;
		    
            pictureBoxShip.Image = (Image)resources.GetObject("pictureBoxShip.Image");
            pictureBoxShip.Location = new Point(732, 2);
            pictureBoxShip.Name = "pictureBoxShip";
            pictureBoxShip.Size = new Size(123, 83);
            pictureBoxShip.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBoxShip.TabIndex = 5;
            pictureBoxShip.TabStop = false;
		    
            timerShip.Enabled = true;
            timerShip.Interval = 2;
            timerShip.Tick += timerShip_Tick;
		    
            timerCanonBall.Interval = 10;
            timerCanonBall.Tick += timerCanonBall_Tick;
		    
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(21, 79, 106);
            ClientSize = new Size(858, 657);
            Controls.Add(labelHint);
            Controls.Add(labelTitle);
            Controls.Add(pictureBoxBoom);
            Controls.Add(pictureBoxCanonBall);
            Controls.Add(pictureBoxCanon);
            Controls.Add(pictureBoxShip);
            Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 204);
            Name = "FormMain";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Морской бой";
            WindowState = FormWindowState.Maximized;
            Load += FormMain_Load;
            KeyUp += FormMain_KeyUp;
            Paint += FormMain_Paint;
            ((System.ComponentModel.ISupportInitialize)pictureBoxBoom).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxCanonBall).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxCanon).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxShip).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label labelHint;
        private Label labelTitle;
        private PictureBox pictureBoxBoom;
        private PictureBox pictureBoxCanonBall;
        private PictureBox pictureBoxCanon;
        private PictureBox pictureBoxShip;
        private System.Windows.Forms.Timer timerShip;
        private System.Windows.Forms.Timer timerCanonBall;
    }
}
