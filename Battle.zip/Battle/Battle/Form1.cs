﻿using System.Drawing.Drawing2D;

namespace Battle
{
    public partial class FormMain : Form
    {
        int dx = -5;

        public FormMain()
        {
            InitializeComponent();
            DoubleBuffered = true;
        }

        private void FormMain_Load(object sender, EventArgs e)
        {
            InitGame();
        }

        void InitGame()
        {
            pictureBoxCanonBall.Visible = false;
            pictureBoxBoom.Visible = false;
            pictureBoxShip.Visible = true;
            pictureBoxShip.Location = new Point(Width - pictureBoxShip.Width - 60, 60);

            pictureBoxCanon.Location = new Point((Width - pictureBoxCanon.Width) / 2,
                Height - pictureBoxCanon.Height - 20);

            pictureBoxCanonBall.Location = new Point(
                pictureBoxCanon.Left + pictureBoxCanon.Width / 2 - pictureBoxCanonBall.Width / 2,
                pictureBoxCanon.Top - pictureBoxCanonBall.Height - 10);

            timerCanonBall.Enabled = false;
            timerShip.Enabled = true;
        }

        private void FormMain_Paint(object sender, PaintEventArgs e)
        {
            int horizon = Height / 3;

            Rectangle sky = new Rectangle(0, 0, Width, horizon);
            using (LinearGradientBrush brush = new LinearGradientBrush(sky,
                Color.FromArgb(214, 236, 247), Color.FromArgb(150, 203, 226), 90))
            {
                e.Graphics.FillRectangle(brush, sky);
            }

            using (SolidBrush sea = new SolidBrush(Color.FromArgb(21, 79, 106)))
            {
                e.Graphics.FillRectangle(sea, 0, horizon, Width, Height - horizon);
            }

            using (Pen line = new Pen(Color.FromArgb(120, 190, 215), 2))
            {
                e.Graphics.DrawLine(line, 0, horizon, Width, horizon);
            }
        }

        private void timerShip_Tick(object sender, EventArgs e)
        {
            pictureBoxShip.Left += dx;

            if (pictureBoxShip.Left < 0 || pictureBoxShip.Right > Width)
                dx = -dx;
        }

        private void FormMain_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                Close();
            }

            if (e.KeyCode == Keys.Space && !timerCanonBall.Enabled)
            {
                pictureBoxCanonBall.Location = new Point(
                    pictureBoxCanon.Left + pictureBoxCanon.Width / 2 - pictureBoxCanonBall.Width / 2,
                    pictureBoxCanon.Top - pictureBoxCanonBall.Height - 10);
                pictureBoxCanonBall.Visible = true;
                timerCanonBall.Enabled = true;
            }
        }

        double Distance(Point a, Point b)
        {
            return Math.Sqrt(Math.Pow(a.X - b.X, 2) + Math.Pow(a.Y - b.Y, 2));
        }

        Point Center(Control control)
        {
            return new Point(control.Left + control.Width / 2, control.Top + control.Height / 2);
        }

        private void timerCanonBall_Tick(object sender, EventArgs e)
        {
            pictureBoxCanonBall.Top -= 5;

            if (Distance(Center(pictureBoxCanonBall), Center(pictureBoxShip)) < pictureBoxShip.Width / 2)
            {
                pictureBoxBoom.Location = new Point(
                    pictureBoxShip.Left + pictureBoxShip.Width / 2 - pictureBoxBoom.Width / 2,
                    pictureBoxShip.Top + pictureBoxShip.Height / 2 - pictureBoxBoom.Height / 2);

                pictureBoxShip.Visible = false;
                pictureBoxCanonBall.Visible = false;
                pictureBoxBoom.Visible = true;
                timerCanonBall.Enabled = false;
                timerShip.Enabled = false;

                if (MessageBox.Show("Корабль подбит! Играем ещё?", "Попадание",
                    MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    InitGame();
                }
                else
                {
                    Close();
                }
            }
            else if (pictureBoxCanonBall.Bottom < 0)
            {
                pictureBoxCanonBall.Visible = false;
                timerCanonBall.Enabled = false;
            }
        }
    }
}
