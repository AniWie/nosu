﻿using Microsoft.VisualBasic;

namespace Plusik
{
    public partial class FormGame : Form
    {
        int number = 1;
        int steps = 0;
        int target = 15;
        Random rnd = new Random();

        public FormGame()
        {
            InitializeComponent();
            UpdateScreen();
        }

        int OptimalSteps(int value)
        {
            int count = 0;
            while (value > 1)
            {
                if (value % 2 == 0)
                    value /= 2;
                else
                    value--;
                count++;
            }
            return count;
        }

        void UpdateScreen()
        {
            labelTarget.Text = target.ToString();
            labelUser.Text = number.ToString();
            labelCountSteps.Text = steps.ToString();
            labelOptimal.Text = "Оптимально: " + OptimalSteps(target);
        }

        void ResetGame()
        {
            number = 1;
            steps = 0;
            UpdateScreen();
        }

        void CheckGame()
        {
            if (number == target)
            {
                if (steps == OptimalSteps(target))
                {
                    MessageBox.Show("Выиграл за оптимальное число шагов!", "Победа");
                }
                else
                {
                    MessageBox.Show("Победа! Можно за меньшее число шагов. Оптимально: " +
                        OptimalSteps(target), "Победа");
                }
                ResetGame();
            }
            else if (number > target)
            {
                MessageBox.Show("Проиграл! Число стало больше цели.", "Проигрыш");
                ResetGame();
            }
        }

        private void pictureBoxPlus_Click(object sender, EventArgs e)
        {
            number++;
            steps++;
            UpdateScreen();
            CheckGame();
        }

        private void pictureBoxMult_Click(object sender, EventArgs e)
        {
            number *= 2;
            steps++;
            UpdateScreen();
            CheckGame();
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            ResetGame();
        }

        private void buttonRandom_Click(object sender, EventArgs e)
        {
            target = rnd.Next(15, 500);
            ResetGame();
        }

        private void buttonUser_Click(object sender, EventArgs e)
        {
            string text = Interaction.InputBox("Введите целевое число от 2 до 500:",
                "Задать число", target.ToString());
            int value;
            if (text == "")
            {
                return;
            }
            if (int.TryParse(text, out value) && value >= 2 && value <= 500)
            {
                target = value;
                ResetGame();
            }
            else
            {
                MessageBox.Show("Нужно ввести число от 2 до 500.");
            }
        }
    }
}
