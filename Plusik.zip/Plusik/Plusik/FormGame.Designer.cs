﻿namespace Plusik
{
    partial class FormGame
    {
        
        private System.ComponentModel.IContainer components = null;

        
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormGame));
            pictureBoxPlus = new PictureBox();
            pictureBoxMult = new PictureBox();
            labelTitle = new Label();
            labelRules = new Label();
            labelTargetCaption = new Label();
            labelTarget = new Label();
            labelUserCaption = new Label();
            labelUser = new Label();
            label1 = new Label();
            labelCountSteps = new Label();
            labelOptimal = new Label();
            buttonClear = new Button();
            buttonRandom = new Button();
            buttonUser = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBoxPlus).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxMult).BeginInit();
            SuspendLayout();
            
            pictureBoxPlus.Image = (Image)resources.GetObject("pictureBoxPlus.Image");
            pictureBoxPlus.Location = new Point(40, 110);
            pictureBoxPlus.Name = "pictureBoxPlus";
            pictureBoxPlus.Size = new Size(220, 220);
            pictureBoxPlus.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBoxPlus.TabIndex = 0;
            pictureBoxPlus.TabStop = false;
            pictureBoxPlus.Click += pictureBoxPlus_Click;
            
            pictureBoxMult.Image = (Image)resources.GetObject("pictureBoxMult.Image");
            pictureBoxMult.Location = new Point(560, 110);
            pictureBoxMult.Name = "pictureBoxMult";
            pictureBoxMult.Size = new Size(220, 220);
            pictureBoxMult.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBoxMult.TabIndex = 1;
            pictureBoxMult.TabStop = false;
            pictureBoxMult.Click += pictureBoxMult_Click;
            
            labelTitle.AutoSize = true;
            labelTitle.Font = new Font("Segoe UI", 26F, FontStyle.Bold, GraphicsUnit.Point, 204);
            labelTitle.ForeColor = Color.FromArgb(47, 61, 52);
            labelTitle.Location = new Point(36, 18);
            labelTitle.Name = "labelTitle";
            labelTitle.Size = new Size(122, 47);
            labelTitle.TabIndex = 2;
            labelTitle.Text = "Плюсик";
            
            labelRules.AutoSize = true;
            labelRules.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point, 204);
            labelRules.ForeColor = Color.FromArgb(107, 107, 107);
            labelRules.Location = new Point(40, 70);
            labelRules.Name = "labelRules";
            labelRules.Size = new Size(318, 19);
            labelRules.TabIndex = 3;
            labelRules.Text = "Дойди до цели кнопками +1 и ×2";
            
            labelTargetCaption.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point, 204);
            labelTargetCaption.ForeColor = Color.FromArgb(107, 107, 107);
            labelTargetCaption.Location = new Point(300, 100);
            labelTargetCaption.Name = "labelTargetCaption";
            labelTargetCaption.Size = new Size(220, 20);
            labelTargetCaption.TabIndex = 4;
            labelTargetCaption.Text = "Цель";
            labelTargetCaption.TextAlign = ContentAlignment.MiddleCenter;
            
            labelTarget.Font = new Font("Segoe UI", 36F, FontStyle.Bold, GraphicsUnit.Point, 204);
            labelTarget.ForeColor = Color.FromArgb(46, 125, 79);
            labelTarget.Location = new Point(300, 122);
            labelTarget.Name = "labelTarget";
            labelTarget.Size = new Size(220, 60);
            labelTarget.TabIndex = 5;
            labelTarget.Text = "15";
            labelTarget.TextAlign = ContentAlignment.MiddleCenter;
            
            labelUserCaption.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point, 204);
            labelUserCaption.ForeColor = Color.FromArgb(107, 107, 107);
            labelUserCaption.Location = new Point(300, 200);
            labelUserCaption.Name = "labelUserCaption";
            labelUserCaption.Size = new Size(220, 20);
            labelUserCaption.TabIndex = 6;
            labelUserCaption.Text = "Твоё число";
            labelUserCaption.TextAlign = ContentAlignment.MiddleCenter;
            
            labelUser.Font = new Font("Segoe UI", 64F, FontStyle.Bold, GraphicsUnit.Point, 204);
            labelUser.ForeColor = Color.FromArgb(43, 43, 43);
            labelUser.Location = new Point(300, 220);
            labelUser.Name = "labelUser";
            labelUser.Size = new Size(220, 100);
            labelUser.TabIndex = 7;
            labelUser.Text = "1";
            labelUser.TextAlign = ContentAlignment.MiddleCenter;
            
            label1.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label1.ForeColor = Color.FromArgb(107, 107, 107);
            label1.Location = new Point(300, 330);
            label1.Name = "label1";
            label1.Size = new Size(60, 25);
            label1.TabIndex = 8;
            label1.Text = "Шаги:";
            label1.TextAlign = ContentAlignment.MiddleRight;
            
            labelCountSteps.Font = new Font("Segoe UI", 11F, FontStyle.Bold, GraphicsUnit.Point, 204);
            labelCountSteps.ForeColor = Color.FromArgb(43, 43, 43);
            labelCountSteps.Location = new Point(365, 330);
            labelCountSteps.Name = "labelCountSteps";
            labelCountSteps.Size = new Size(60, 25);
            labelCountSteps.TabIndex = 9;
            labelCountSteps.Text = "0";
            labelCountSteps.TextAlign = ContentAlignment.MiddleLeft;
            
            labelOptimal.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point, 204);
            labelOptimal.ForeColor = Color.FromArgb(107, 107, 107);
            labelOptimal.Location = new Point(300, 360);
            labelOptimal.Name = "labelOptimal";
            labelOptimal.Size = new Size(220, 25);
            labelOptimal.TabIndex = 10;
            labelOptimal.Text = "Оптимально: 6";
            labelOptimal.TextAlign = ContentAlignment.MiddleCenter;
            
            buttonClear.BackColor = Color.White;
            buttonClear.Cursor = Cursors.Hand;
            buttonClear.FlatAppearance.BorderColor = Color.FromArgb(216, 210, 198);
            buttonClear.FlatAppearance.MouseDownBackColor = Color.FromArgb(228, 221, 208);
            buttonClear.FlatAppearance.MouseOverBackColor = Color.FromArgb(239, 234, 224);
            buttonClear.FlatStyle = FlatStyle.Flat;
            buttonClear.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point, 204);
            buttonClear.Location = new Point(40, 470);
            buttonClear.Name = "buttonClear";
            buttonClear.Size = new Size(230, 56);
            buttonClear.TabIndex = 11;
            buttonClear.Text = "Начать сначала";
            buttonClear.UseVisualStyleBackColor = false;
            buttonClear.Click += buttonClear_Click;
            
            buttonRandom.BackColor = Color.White;
            buttonRandom.Cursor = Cursors.Hand;
            buttonRandom.FlatAppearance.BorderColor = Color.FromArgb(216, 210, 198);
            buttonRandom.FlatAppearance.MouseDownBackColor = Color.FromArgb(228, 221, 208);
            buttonRandom.FlatAppearance.MouseOverBackColor = Color.FromArgb(239, 234, 224);
            buttonRandom.FlatStyle = FlatStyle.Flat;
            buttonRandom.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point, 204);
            buttonRandom.Location = new Point(295, 470);
            buttonRandom.Name = "buttonRandom";
            buttonRandom.Size = new Size(230, 56);
            buttonRandom.TabIndex = 12;
            buttonRandom.Text = "Случайное число";
            buttonRandom.UseVisualStyleBackColor = false;
            buttonRandom.Click += buttonRandom_Click;
            
            buttonUser.BackColor = Color.White;
            buttonUser.Cursor = Cursors.Hand;
            buttonUser.FlatAppearance.BorderColor = Color.FromArgb(216, 210, 198);
            buttonUser.FlatAppearance.MouseDownBackColor = Color.FromArgb(228, 221, 208);
            buttonUser.FlatAppearance.MouseOverBackColor = Color.FromArgb(239, 234, 224);
            buttonUser.FlatStyle = FlatStyle.Flat;
            buttonUser.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point, 204);
            buttonUser.Location = new Point(550, 470);
            buttonUser.Name = "buttonUser";
            buttonUser.Size = new Size(230, 56);
            buttonUser.TabIndex = 13;
            buttonUser.Text = "Задать число";
            buttonUser.UseVisualStyleBackColor = false;
            buttonUser.Click += buttonUser_Click;
            
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(246, 243, 236);
            ClientSize = new Size(820, 580);
            Controls.Add(buttonUser);
            Controls.Add(buttonRandom);
            Controls.Add(buttonClear);
            Controls.Add(labelOptimal);
            Controls.Add(labelCountSteps);
            Controls.Add(label1);
            Controls.Add(labelUser);
            Controls.Add(labelUserCaption);
            Controls.Add(labelTarget);
            Controls.Add(labelTargetCaption);
            Controls.Add(labelRules);
            Controls.Add(labelTitle);
            Controls.Add(pictureBoxMult);
            Controls.Add(pictureBoxPlus);
            Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 204);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            Name = "FormGame";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Плюсик";
            ((System.ComponentModel.ISupportInitialize)pictureBoxPlus).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxMult).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBoxPlus;
        private PictureBox pictureBoxMult;
        private Label labelTitle;
        private Label labelRules;
        private Label labelTargetCaption;
        private Label labelTarget;
        private Label labelUserCaption;
        private Label labelUser;
        private Label label1;
        private Label labelCountSteps;
        private Label labelOptimal;
        private Button buttonClear;
        private Button buttonRandom;
        private Button buttonUser;
    }
}
